/* Design: Sofisticação Clássica com Acentos Modernos */
/* Seção de contato com formulário e informações */

import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { useState } from "react";

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    message: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Formulário enviado:", formData);
    setFormData({ name: "", email: "", phone: "", message: "" });
    alert("Mensagem enviada com sucesso! Entraremos em contato em breve.");
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: "Endereço",
      content: "Av. Paulista, 1000 - São Paulo, SP",
    },
    {
      icon: Phone,
      title: "Telefone",
      content: "(11) 99999-9999",
    },
    {
      icon: Mail,
      title: "Email",
      content: "contato@clinicamedica.com.br",
    },
    {
      icon: Clock,
      title: "Horário",
      content: "Seg-Sex: 8h às 18h",
    },
  ];

  return (
    <section id="contact" className="py-20 bg-gradient-to-b from-white to-muted/20">
      <div className="container">
        {/* Cabeçalho */}
        <div className="text-center mb-16 animate-fade-in-up">
          <div className="flex justify-center mb-4">
            <div className="divider-gold" />
          </div>
          <h2
            className="text-4xl md:text-5xl font-bold text-primary mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Entre em Contato
          </h2>
          <p className="text-lg text-secondary max-w-2xl mx-auto">
            Estamos aqui para responder suas dúvidas e agendar sua consulta
          </p>
        </div>

        {/* Conteúdo */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Informações de Contato */}
          <div className="animate-slide-in-left">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {contactInfo.map((info, index) => {
                const IconComponent = info.icon;
                return (
                  <div
                    key={index}
                    className="p-6 bg-white rounded-lg shadow-elegant hover:shadow-elegant-hover transition-all duration-500"
                  >
                    <div className="icon-circle mb-4">
                      <IconComponent size={24} />
                    </div>
                    <h3
                      className="font-bold text-primary mb-2"
                      style={{ fontFamily: "var(--font-display)" }}
                    >
                      {info.title}
                    </h3>
                    <p className="text-secondary text-sm">{info.content}</p>
                  </div>
                );
              })}
            </div>

            {/* WhatsApp CTA */}
            <div className="mt-8 p-8 bg-gradient-to-r from-primary to-primary/80 rounded-lg shadow-elegant">
              <h3
                className="text-2xl font-bold text-white mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Agende Agora
              </h3>
              <p className="text-white/90 mb-6">
                Clique no botão abaixo para conversar conosco pelo WhatsApp
              </p>
              <a
                href="https://wa.me/5511999999999"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-8 py-3 bg-white text-primary font-semibold rounded-lg hover:shadow-lg transition-all duration-300 hover:scale-105"
              >
                Conversar no WhatsApp
              </a>
            </div>
          </div>

          {/* Formulário */}
          <div className="animate-slide-in-right">
            <form
              onSubmit={handleSubmit}
              className="p-8 bg-white rounded-lg shadow-elegant space-y-6"
            >
              {/* Nome */}
              <div>
                <label className="block text-sm font-semibold text-primary mb-2">
                  Nome Completo
                </label>
                <input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                  placeholder="Seu nome"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-semibold text-primary mb-2">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                  placeholder="seu@email.com"
                />
              </div>

              {/* Telefone */}
              <div>
                <label className="block text-sm font-semibold text-primary mb-2">
                  Telefone
                </label>
                <input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all"
                  placeholder="(11) 99999-9999"
                />
              </div>

              {/* Mensagem */}
              <div>
                <label className="block text-sm font-semibold text-primary mb-2">
                  Mensagem
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={5}
                  className="w-full px-4 py-3 border border-border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent focus:border-transparent transition-all resize-none"
                  placeholder="Sua mensagem aqui..."
                />
              </div>

              {/* Botão */}
              <button
                type="submit"
                className="w-full btn-elegant"
              >
                Enviar Mensagem
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
