/* Design: Sofisticação Clássica com Acentos Modernos */
/* Footer elegante com redes sociais e informações */

import { Instagram, Facebook, Linkedin, Heart } from "lucide-react";
import LocationMap from "./LocationMap";

export default function Footer() {
  const socialLinks = [
    { icon: Instagram, href: "https://instagram.com", label: "Instagram" },
    { icon: Facebook, href: "https://facebook.com", label: "Facebook" },
    { icon: Linkedin, href: "https://linkedin.com", label: "LinkedIn" },
  ];

  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-white border-top-gold">
      <div className="container py-16">
        {/* Conteúdo Principal */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Logo e Descrição */}
          <div className="col-span-1 md:col-span-1">
            <img 
              src="https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/un-logo_0ee12565.png" 
              alt="Unique Instituto de Cirurgia" 
              className="h-16 w-auto object-contain mb-4"
            />
            <p className="text-white/70 text-sm">
              Sofisticação e cuidado em cada atendimento
            </p>
          </div>

          {/* Links Rápidos */}
          <div>
            <h4 className="font-bold mb-4" style={{ fontFamily: "var(--font-display)" }}>
              Links Rápidos
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#doctors" className="text-white/70 hover:text-accent transition-colors">
                  Doutores
                </a>
              </li>
              <li>
                <a href="#services" className="text-white/70 hover:text-accent transition-colors">
                  Serviços
                </a>
              </li>
              <li>
                <a href="#testimonials" className="text-white/70 hover:text-accent transition-colors">
                  Depoimentos
                </a>
              </li>
              <li>
                <a href="#contact" className="text-white/70 hover:text-accent transition-colors">
                  Contato
                </a>
              </li>
            </ul>
          </div>

          {/* Especialidades */}
          <div>
            <h4 className="font-bold mb-4" style={{ fontFamily: "var(--font-display)" }}>
              Especialidades
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <a href="#" className="text-white/70 hover:text-accent transition-colors">
                  Cardiologia
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-accent transition-colors">
                  Neurologia
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-accent transition-colors">
                  Pediatria
                </a>
              </li>
              <li>
                <a href="#" className="text-white/70 hover:text-accent transition-colors">
                  Dermatologia
                </a>
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h4 className="font-bold mb-4" style={{ fontFamily: "var(--font-display)" }}>
              Contato
            </h4>
            <ul className="space-y-2 text-sm">
              <li className="text-white/70">
                <span className="font-semibold">Tel:</span> (11) 99999-9999
              </li>
              <li className="text-white/70">
                <span className="font-semibold">Email:</span> contato@clinicamedica.com.br
              </li>
              <li className="text-white/70">
                <span className="font-semibold">End:</span> Av. Paulista, 1000
              </li>
              <li className="text-white/70">
                <span className="font-semibold">Horário:</span> Seg-Sex 8h-18h
              </li>
            </ul>
          </div>
        </div>

        {/* Divisor */}
        <div className="border-t border-white/20 py-8" />

        {/* Redes Sociais e Copyright */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Redes Sociais */}
          <div className="flex gap-4">
            {socialLinks.map((link) => {
              const IconComponent = link.icon;
              return (
                <a
                  key={link.label}
                  href={link.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="icon-circle"
                  title={link.label}
                >
                  <IconComponent size={20} />
                </a>
              );
            })}
          </div>

          {/* Copyright */}
          <div className="text-center md:text-right text-sm text-white/70">
            <p className="flex items-center justify-center md:justify-end gap-1">
              Feito com <Heart size={16} className="fill-accent text-accent" /> por Unique Instituto de Cirurgia
            </p>
            <p>&copy; {currentYear} Todos os direitos reservados.</p>
          </div>
        </div>
      </div>

      {/* Mapa de Localização */}
      <div className="bg-white text-foreground">
        <LocationMap 
          latitude={-23.5505}
          longitude={-46.6333}
          address="Av. Paulista, 1000 - São Paulo, SP"
          phone="(11) 99999-9999"
          hours="Seg-Sex 8h-18h | Sáb 9h-13h"
        />
      </div>
    </footer>
  );
}
