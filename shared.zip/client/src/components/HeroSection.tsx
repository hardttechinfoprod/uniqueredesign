/* Design: Sofisticação Clássica com Acentos Modernos */
/* Hero section com imagem de fundo e call-to-action */

export default function HeroSection() {
  return (
    <section
      className="relative w-full h-screen flex items-center justify-center overflow-hidden mt-20"
      style={{
        backgroundImage: "url('https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/hero-medical-clinic-Svdawct3tTCFixhN7hBZrs.webp')",
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      {/* Overlay Gradiente */}
      <div className="absolute inset-0 bg-gradient-to-r from-primary/90 via-primary/70 to-transparent" />

      {/* Conteúdo */}
      <div className="container relative z-10 flex flex-col items-start justify-center h-full max-w-2xl">
        <div className="animate-fade-in-up">
          {/* Linha Decorativa */}
          <div className="divider-gold mb-6" />

          {/* Título */}
          <h1
            className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Saúde com Sofisticação
          </h1>

          {/* Subtítulo */}
          <p className="text-xl md:text-2xl text-white/90 mb-8 font-light max-w-xl">
            Atendimento médico de excelência com profissionais altamente qualificados e dedicados ao seu bem-estar.
          </p>

          {/* Linha Decorativa */}
          <div className="divider-gold mb-8" />

          {/* CTAs */}
          <div className="flex flex-col sm:flex-row gap-4">
            <a
              href="https://wa.me/5511999999999"
              target="_blank"
              rel="noopener noreferrer"
              className="btn-elegant inline-block text-center"
            >
              Agendar Consulta
            </a>
            <a
              href="#doctors"
              className="btn-elegant-outline inline-block text-center text-white border-white hover:bg-white hover:text-primary"
            >
              Conhecer Doutores
            </a>
          </div>
        </div>
      </div>

      {/* Elemento Flutuante */}
      <div className="absolute bottom-8 right-8 animate-float hidden lg:block">
        <div className="w-20 h-20 rounded-full bg-accent/20 border-2 border-accent/40" />
      </div>
    </section>
  );
}
