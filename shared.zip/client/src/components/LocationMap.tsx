/* Design: Sofisticação Clássica com Acentos Modernos */
/* Componente de mapa do Google Maps com localização da clínica */

import { MapPin, Clock, Phone } from "lucide-react";
import { useState } from "react";

interface LocationMapProps {
  latitude?: number;
  longitude?: number;
  address?: string;
  phone?: string;
  hours?: string;
}

export default function LocationMap({
  latitude = -23.5505,
  longitude = -46.6333,
  address = "Av. Paulista, 1000 - São Paulo, SP",
  phone = "(11) 99999-9999",
  hours = "Seg-Sex 8h-18h | Sáb 9h-13h"
}: LocationMapProps) {
  const [mapUrl] = useState(
    `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.1976305261235!2d${longitude}!3d${latitude}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce59c8da0edb6d%3A0xab35da2f5ca62674!2sAv.%20Paulista%2C%201000%20-%20S%C3%A3o%20Paulo%2C%20SP!5e0!3m2!1spt-BR!2sbr!4v1234567890`
  );

  return (
    <div className="location-map-container">
      {/* Informações à Esquerda */}
      <div className="location-info">
        <h3 className="location-title" style={{ fontFamily: "var(--font-display)" }}>
          Visite-nos
        </h3>
        
        {/* Endereço */}
        <div className="location-item">
          <div className="location-icon">
            <MapPin size={20} />
          </div>
          <div>
            <p className="location-label">Endereço</p>
            <p className="location-value">{address}</p>
          </div>
        </div>

        {/* Telefone */}
        <div className="location-item">
          <div className="location-icon">
            <Phone size={20} />
          </div>
          <div>
            <p className="location-label">Telefone</p>
            <a href={`tel:${phone.replace(/\D/g, '')}`} className="location-value location-link">
              {phone}
            </a>
          </div>
        </div>

        {/* Horário */}
        <div className="location-item">
          <div className="location-icon">
            <Clock size={20} />
          </div>
          <div>
            <p className="location-label">Horário</p>
            <p className="location-value">{hours}</p>
          </div>
        </div>
      </div>

      {/* Mapa à Direita */}
      <div className="location-map-wrapper">
        <iframe
          title="Localização da Unique Instituto de Cirurgia"
          className="location-map"
          src={mapUrl}
          style={{ 
            width: "100%", 
            height: "100%",
            border: "none",
            borderRadius: "16px"
          }}
          allowFullScreen
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
        />
      </div>
    </div>
  );
}
