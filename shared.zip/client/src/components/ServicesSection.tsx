/* Design: Sofisticação Clássica com Acentos Modernos */
/* Seção de serviços com ícones e descrições */

import { Heart, Brain, Baby, Zap, Bone, Stethoscope } from "lucide-react";

const services = [
  {
    icon: Heart,
    title: "Cardiologia",
    description: "Diagnóstico e tratamento de doenças cardiovasculares com tecnologia avançada",
  },
  {
    icon: Brain,
    title: "Neurologia",
    description: "Especialização em distúrbios neurológicos e doenças do sistema nervoso",
  },
  {
    icon: Baby,
    title: "Pediatria",
    description: "Cuidado integral de crianças e adolescentes com abordagem humanizada",
  },
  {
    icon: Zap,
    title: "Dermatologia",
    description: "Tratamentos estéticos e dermatologia clínica com procedimentos modernos",
  },
  {
    icon: Bone,
    title: "Ortopedia",
    description: "Cirurgia ortopédica e traumatologia com excelência técnica",
  },
  {
    icon: Stethoscope,
    title: "Consultas Gerais",
    description: "Atendimento médico geral com avaliação completa da saúde",
  },
];

export default function ServicesSection() {
  return (
    <section id="services" className="py-20 bg-gradient-to-b from-white to-muted/20">
      <div className="container">
        {/* Cabeçalho */}
        <div className="text-center mb-16 animate-fade-in-up">
          <div className="flex justify-center mb-4">
            <div className="divider-gold" />
          </div>
          <h2
            className="text-4xl md:text-5xl font-bold text-primary mb-4"
            style={{ fontFamily: "var(--font-display)" }}
          >
            Nossos Serviços
          </h2>
          <p className="text-lg text-secondary max-w-2xl mx-auto">
            Oferecemos uma ampla gama de serviços médicos especializados para sua saúde
          </p>
        </div>

        {/* Grid de Serviços */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div
                key={index}
                className="p-8 bg-white rounded-lg shadow-elegant hover:shadow-elegant-hover transition-all duration-500 group"
                style={{
                  animation: `fadeInUp 600ms cubic-bezier(0.4, 0, 0.2, 1) forwards`,
                  animationDelay: `${index * 100}ms`,
                  opacity: 0,
                }}
              >
                {/* Ícone */}
                <div className="icon-circle mb-6">
                  <IconComponent size={24} />
                </div>

                {/* Título */}
                <h3
                  className="text-xl font-bold text-primary mb-3"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  {service.title}
                </h3>

                {/* Descrição */}
                <p className="text-secondary text-sm leading-relaxed">{service.description}</p>

                {/* Linha Decorativa */}
                <div className="mt-6 h-1 w-8 bg-accent rounded-full group-hover:w-12 transition-all duration-300" />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
