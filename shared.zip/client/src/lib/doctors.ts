/* Design: Sofisticação Clássica com Acentos Modernos */
/* Dados dos doutores com informações completas para galeria e páginas individuais */

export interface Doctor {
  id: string;
  name: string;
  specialty: string;
  image: string;
  imageCompressed: string;
  bio: string;
  experience: string;
  education: string;
  certifications: string[];
  languages: string[];
  consultationTypes: string[];
  availability: string;
}

export const doctors: Doctor[] = [
  {
    id: "cardiologist",
    name: "Dr. Carlos Mendes",
    specialty: "Cardiologista",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-1-cardiologist-4cgm86J7Y4xUKSLHcWXTeC.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-1-cardiologist-WtxALUaUL9LsWupTgJUpx5.webp",
    bio: "Com mais de 20 anos de experiência em cardiologia, o Dr. Carlos Mendes é especialista em prevenção e tratamento de doenças cardiovasculares. Formado pela Universidade de São Paulo, realizou residência em cardiologia clínica e intervencionista, com especialização em ecocardiografia.",
    experience: "20+ anos em cardiologia clínica e intervencionista",
    education: "Graduação em Medicina - USP\nResidência em Cardiologia - Instituto Dante Pazzanese\nEspecialização em Ecocardiografia - Universidade de São Paulo",
    certifications: [
      "Certificado em Cardiologia Clínica",
      "Certificado em Ecocardiografia",
      "Certificado em Cardiologia Intervencionista",
      "Membro da Sociedade Brasileira de Cardiologia"
    ],
    languages: ["Português", "Inglês", "Espanhol"],
    consultationTypes: ["Consulta Presencial", "Telemedicina", "Acompanhamento"],
    availability: "Segunda a Sexta, 8h às 18h"
  },
  {
    id: "neurologist",
    name: "Dra. Emily Rogers",
    specialty: "Neurologista",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-2-neurologist-AKjerXzcaiYs8UqAmvaGXJ.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-2-neurologist-bi5sNrMvvEUK3CFVN7n9RR.webp",
    bio: "A Dra. Emily Rogers é uma neurologista renomada com 15 anos de experiência no diagnóstico e tratamento de distúrbios neurológicos. Especialista em enxaquecas, epilepsia e doenças neurodegenerativas, com formação em instituições de excelência.",
    experience: "15+ anos em neurologia clínica e diagnóstico",
    education: "Graduação em Medicina - Universidade Federal do Rio de Janeiro\nResidência em Neurologia - Hospital das Clínicas\nEspecialização em Neurologia Clínica - Universidade de Campinas",
    certifications: [
      "Certificado em Neurologia Clínica",
      "Certificado em Eletroencefalografia",
      "Certificado em Neuroimagem",
      "Membro da Academia Brasileira de Neurologia"
    ],
    languages: ["Português", "Inglês", "Francês"],
    consultationTypes: ["Consulta Presencial", "Telemedicina", "Acompanhamento"],
    availability: "Segunda a Quinta, 9h às 17h"
  },
  {
    id: "pediatrician",
    name: "Dr. Marcus Silva",
    specialty: "Pediatra",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-3-pediatrician-AWBUv2E3VXSqxGkwvHMF4k.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-3-pediatrician-EVggSWWsX4SnhUjNML4j8t.webp",
    bio: "O Dr. Marcus Silva é pediatra com 18 anos de experiência no cuidado integral de crianças e adolescentes. Dedicado ao bem-estar infantil, oferece atendimento humanizado e acompanhamento completo do desenvolvimento.",
    experience: "18+ anos em pediatria e saúde infantil",
    education: "Graduação em Medicina - Universidade Federal de Minas Gerais\nResidência em Pediatria - Hospital Infantil João Paulo II\nEspecialização em Pediatria Geral - Universidade Federal de Minas Gerais",
    certifications: [
      "Certificado em Pediatria Geral",
      "Certificado em Puericultura",
      "Certificado em Pediatria do Desenvolvimento",
      "Membro da Sociedade Brasileira de Pediatria"
    ],
    languages: ["Português", "Inglês"],
    consultationTypes: ["Consulta Presencial", "Acompanhamento", "Vacinação"],
    availability: "Segunda a Sexta, 8h às 18h"
  },
  {
    id: "dermatologist",
    name: "Dra. Isabella Costa",
    specialty: "Dermatologista",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-4-dermatologist-AnZkJFP2aeSVk4ZfUSewW.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-4-dermatologist-ArhKX5jajGzJRXohHYYGxR.webp",
    bio: "A Dra. Isabella Costa é dermatologista com 14 anos de experiência em tratamentos estéticos e dermatologia clínica. Especialista em laser, peeling químico e procedimentos minimamente invasivos para rejuvenescimento da pele.",
    experience: "14+ anos em dermatologia clínica e estética",
    education: "Graduação em Medicina - Universidade de São Paulo\nResidência em Dermatologia - Instituto de Dermatologia\nEspecialização em Dermatologia Estética - Universidade de São Paulo",
    certifications: [
      "Certificado em Dermatologia Clínica",
      "Certificado em Dermatologia Estética",
      "Certificado em Laser e Luz Pulsada",
      "Membro da Sociedade Brasileira de Dermatologia"
    ],
    languages: ["Português", "Inglês", "Italiano"],
    consultationTypes: ["Consulta Presencial", "Procedimentos Estéticos", "Acompanhamento"],
    availability: "Segunda a Sexta, 10h às 19h"
  },
  {
    id: "orthopedist",
    name: "Dr. Michael Roberts",
    specialty: "Cirurgião Ortopédico",
    image: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-5-orthopedist-mn4BJXDNAFYemyL7VixZaW.png",
    imageCompressed: "https://d2xsxph8kpxj0f.cloudfront.net/310519663326837738/iJrANnw4aHJXYPH9pdUbod/doctor-5-orthopedist-88PHWC3jpkjz5DVtoPTYGt.webp",
    bio: "O Dr. Michael Roberts é cirurgião ortopédico com 22 anos de experiência em cirurgias de joelho, ombro e coluna. Especialista em artroscopia e reconstrução ligamentar, oferece tratamento completo de lesões ortopédicas.",
    experience: "22+ anos em cirurgia ortopédica e traumatologia",
    education: "Graduação em Medicina - Universidade Federal do Rio Grande do Sul\nResidência em Ortopedia - Hospital de Clínicas de Porto Alegre\nEspecialização em Cirurgia de Joelho - Universidade Federal do Rio Grande do Sul",
    certifications: [
      "Certificado em Cirurgia Ortopédica",
      "Certificado em Artroscopia",
      "Certificado em Cirurgia de Coluna",
      "Membro da Sociedade Brasileira de Ortopedia e Traumatologia"
    ],
    languages: ["Português", "Inglês", "Alemão"],
    consultationTypes: ["Consulta Presencial", "Cirurgia", "Reabilitação"],
    availability: "Segunda a Sexta, 8h às 17h"
  }
];

export function getDoctorById(id: string): Doctor | undefined {
  return doctors.find(doctor => doctor.id === id);
}

export function getAllDoctors(): Doctor[] {
  return doctors;
}
