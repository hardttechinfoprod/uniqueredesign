/* Design: Sofisticação Clássica com Acentos Modernos */
/* Página individual de doutor com bio, certificações e informações */

import { useParams } from "wouter";
import { getDoctorById } from "@/lib/doctors";
import { ArrowLeft, Award, Languages, Clock, FileText } from "lucide-react";

export default function DoctorProfile() {
  const { id } = useParams<{ id: string }>();
  const doctor = getDoctorById(id || "");

  if (!doctor) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center">
        <h1 className="text-3xl font-bold text-primary mb-4" style={{ fontFamily: "var(--font-display)" }}>
          Doutor não encontrado
        </h1>
        <a href="/" className="btn-elegant">Voltar para Início</a>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white pt-32 pb-20">
      <div className="container">
        {/* Botão Voltar */}
        <a href="/#doctors" className="inline-flex items-center gap-2 text-accent hover:text-primary transition-colors mb-8 group">
          <ArrowLeft size={20} className="group-hover:-translate-x-1 transition-transform" />
          <span className="font-semibold">Voltar para Doutores</span>
        </a>

        {/* Conteúdo Principal */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Coluna Esquerda - Imagem e Info Rápida */}
          <div className="lg:col-span-1 animate-fade-in-scale">
            {/* Imagem */}
            <div className="rounded-lg overflow-hidden shadow-elegant mb-8">
              <img
                src={doctor.image}
                alt={doctor.name}
                className="w-full h-96 object-cover"
              />
            </div>

            {/* Card de Informações Rápidas */}
            <div className="bg-gradient-to-br from-primary to-primary/80 text-white rounded-lg p-8 shadow-elegant">
              <h2
                className="text-2xl font-bold mb-2"
                style={{ fontFamily: "var(--font-display)" }}
              >
                {doctor.name}
              </h2>
              <p className="text-accent font-semibold mb-6">{doctor.specialty}</p>

              {/* Disponibilidade */}
              <div className="mb-6 pb-6 border-b border-white/20">
                <div className="flex items-center gap-3 text-white/90">
                  <Clock size={18} />
                  <div>
                    <p className="text-sm font-semibold">Disponibilidade</p>
                    <p className="text-sm">{doctor.availability}</p>
                  </div>
                </div>
              </div>

              {/* Botão WhatsApp */}
              <a
                href="https://wa.me/5511999999999"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full px-6 py-3 bg-white text-primary font-semibold rounded-lg hover:shadow-lg transition-all duration-300 hover:scale-105 text-center block"
              >
                Agendar Consulta
              </a>
            </div>
          </div>

          {/* Coluna Direita - Informações Detalhadas */}
          <div className="lg:col-span-2 animate-slide-in-right space-y-8">
            {/* Bio */}
            <section>
              <h3
                className="text-2xl font-bold text-primary mb-4"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Sobre
              </h3>
              <p className="text-secondary leading-relaxed text-lg">{doctor.bio}</p>
            </section>

            {/* Experiência */}
            <section>
              <div className="flex items-center gap-3 mb-4">
                <FileText className="text-accent" size={24} />
                <h3
                  className="text-2xl font-bold text-primary"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Experiência
                </h3>
              </div>
              <p className="text-secondary text-lg font-semibold">{doctor.experience}</p>
            </section>

            {/* Educação */}
            <section>
              <h3
                className="text-2xl font-bold text-primary mb-4"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Formação Acadêmica
              </h3>
              <div className="space-y-3">
                {doctor.education.split("\n").map((edu, index) => (
                  <div key={index} className="flex gap-3">
                    <div className="w-2 h-2 rounded-full bg-accent mt-2 flex-shrink-0" />
                    <p className="text-secondary">{edu}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Certificações */}
            <section>
              <div className="flex items-center gap-3 mb-4">
                <Award className="text-accent" size={24} />
                <h3
                  className="text-2xl font-bold text-primary"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Certificações
                </h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {doctor.certifications.map((cert, index) => (
                  <div
                    key={index}
                    className="p-4 bg-gradient-to-br from-muted/50 to-muted/20 rounded-lg border border-accent/20"
                  >
                    <p className="text-secondary font-medium">{cert}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* Idiomas */}
            <section>
              <div className="flex items-center gap-3 mb-4">
                <Languages className="text-accent" size={24} />
                <h3
                  className="text-2xl font-bold text-primary"
                  style={{ fontFamily: "var(--font-display)" }}
                >
                  Idiomas
                </h3>
              </div>
              <div className="flex flex-wrap gap-3">
                {doctor.languages.map((lang, index) => (
                  <span
                    key={index}
                    className="px-4 py-2 bg-accent/10 text-accent font-semibold rounded-full border border-accent/20"
                  >
                    {lang}
                  </span>
                ))}
              </div>
            </section>

            {/* Tipos de Consulta */}
            <section>
              <h3
                className="text-2xl font-bold text-primary mb-4"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Tipos de Consulta
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {doctor.consultationTypes.map((type, index) => (
                  <div
                    key={index}
                    className="p-4 bg-white border-2 border-accent/20 rounded-lg hover:border-accent transition-colors"
                  >
                    <p className="text-secondary font-medium">{type}</p>
                  </div>
                ))}
              </div>
            </section>

            {/* CTA Final */}
            <div className="mt-12 p-8 bg-gradient-to-r from-primary to-primary/80 rounded-lg shadow-elegant">
              <h3
                className="text-2xl font-bold text-white mb-3"
                style={{ fontFamily: "var(--font-display)" }}
              >
                Pronto para Agendar?
              </h3>
              <p className="text-white/90 mb-6">
                Entre em contato conosco para agendar sua consulta com o Dr(a). {doctor.name}
              </p>
              <a
                href="https://wa.me/5511999999999"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block px-8 py-3 bg-white text-primary font-semibold rounded-lg hover:shadow-lg transition-all duration-300 hover:scale-105"
              >
                Agendar Agora
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
